#
# TABLE STRUCTURE FOR: ea_appointment_logs
#

DROP TABLE IF EXISTS `ea_appointment_logs`;

CREATE TABLE `ea_appointment_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (1, 175, NULL, NULL, 1, 'Dr Sahu sahu', 'Rescheduled (Drag & Drop)', 'New Time: 2026-08-07 09:15:00 to 2026-08-07 09:30:00', '2026-08-07 17:31:01');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (2, 175, NULL, NULL, 1, 'Dr Sahu sahu', 'Rescheduled (Drag & Drop)', 'New Time: 2026-08-07 09:30:00 to 2026-08-07 09:45:00', '2026-08-07 17:34:39');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (3, 177, NULL, NULL, 1, 'Dr Sahu sahu', 'Type Changed to Video', '', '2026-08-10 10:36:42');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (4, 178, NULL, NULL, 1, 'Dr Sahu sahu', 'WhatsApp Marked as Sent', '', '2026-08-10 10:50:29');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (5, 178, NULL, NULL, 1, 'Dr Sahu sahu', 'Status Changed to Confirmed', '', '2026-08-10 10:50:51');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (6, 182, NULL, NULL, 1, 'Dr Sahu sahu', 'Canceled', 'Reason: noting', '2026-08-10 10:51:19');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (7, 183, NULL, NULL, 1, 'Dr Sahu sahu', 'Created Appointment (Backend)', '', '2026-08-10 10:56:14');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (8, 183, NULL, NULL, 1, 'Dr Sahu sahu', 'Checked In', '', '2026-08-10 10:56:25');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (9, 183, NULL, NULL, 1, 'Dr Sahu sahu', 'Checked Out', '', '2026-08-10 10:58:21');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (10, 177, 158, 'pp kumar', 1, 'Dr Sahu sahu', 'Type Changed to Video', '', '2026-08-10 12:03:40');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (11, 183, 164, 'sdacedcercwr', 1, 'Dr Sahu sahu', 'Type Changed to In-clinic', '', '2026-08-10 12:05:30');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (12, 184, 163, 'qwdwqdwqed', 1, 'Dr Sahu sahu', 'Created Appointment (Backend)', '', '2026-08-13 11:05:40');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (13, 184, 163, 'qwdwqdwqed', 1, 'Dr Sahu sahu', 'Rescheduled (Drag & Drop)', 'New Time: 2026-08-13 12:00:00 to 2026-08-13 12:15:00', '2026-08-13 11:06:26');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (14, 184, 163, 'qwdwqdwqed', 1, 'Dr Sahu sahu', 'Rescheduled (Drag & Drop)', 'New Time: 2026-08-13 12:45:00 to 2026-08-13 13:00:00', '2026-08-13 11:20:33');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (15, 184, 163, 'qwdwqdwqed', 1, 'Dr Sahu sahu', 'Rescheduled (Drag & Drop)', 'New Time: 2026-08-14 11:30:00 to 2026-08-14 11:45:00', '2026-08-13 11:20:37');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (16, 184, 163, 'qwdwqdwqed', 1, 'Dr Sahu sahu', 'Rescheduled (Drag & Drop)', 'New Time: 2026-08-17 11:30:00 to 2026-08-17 11:45:00', '2026-08-13 11:20:43');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (17, 184, 163, 'qwdwqdwqed', 1, 'Dr Sahu sahu', 'Rescheduled (Drag & Drop)', 'New Time: 2026-08-17 10:00:00 to 2026-08-17 10:15:00', '2026-08-13 11:25:17');
INSERT INTO `ea_appointment_logs` (`id`, `appointment_id`, `customer_id`, `customer_name`, `user_id`, `user_name`, `action`, `details`, `created_at`) VALUES (18, 187, 171, 'pp kumar', 1, 'Dr Sahu sahu', 'Created Appointment (Backend)', '', '2026-08-14 17:59:57');


#
# TABLE STRUCTURE FOR: ea_appointments
#

DROP TABLE IF EXISTS `ea_appointments`;

CREATE TABLE `ea_appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `book_datetime` datetime DEFAULT NULL,
  `start_datetime` datetime DEFAULT NULL,
  `end_datetime` datetime DEFAULT NULL,
  `location` text DEFAULT NULL,
  `meeting_link` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `hash` text DEFAULT NULL,
  `color` varchar(256) DEFAULT '#7cbae8',
  `status` varchar(512) DEFAULT '',
  `is_canceled` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 for Canceled, 0 for Active',
  `appointment_type` varchar(50) DEFAULT 'in-clinic',
  `is_unavailability` tinyint(4) NOT NULL DEFAULT 0,
  `check_type` tinyint(4) DEFAULT NULL COMMENT '1 for Check In, 0 for Check Out',
  `is_whatsapp_sent` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 for WhatsApp Sent, 0 for Not Sent',
  `id_users_provider` int(11) DEFAULT NULL,
  `id_users_customer` int(11) DEFAULT NULL,
  `id_services` int(11) DEFAULT NULL,
  `id_google_calendar` text DEFAULT NULL,
  `id_caldav_calendar` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_users_provider` (`id_users_provider`),
  KEY `id_users_customer` (`id_users_customer`),
  KEY `id_services` (`id_services`),
  CONSTRAINT `appointments_services` FOREIGN KEY (`id_services`) REFERENCES `ea_services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `appointments_users_customer` FOREIGN KEY (`id_users_customer`) REFERENCES `ea_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `appointments_users_provider` FOREIGN KEY (`id_users_provider`) REFERENCES `ea_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (78, '2026-07-29 08:14:04', NULL, NULL, '2026-07-27 10:30:00', '2026-07-27 10:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, NULL, 1, 19, 101, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (79, '2026-07-29 08:14:04', NULL, NULL, '2026-07-27 11:30:00', '2026-07-27 11:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, NULL, 0, 19, 102, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (80, '2026-07-29 08:14:04', NULL, NULL, '2026-07-27 13:00:00', '2026-07-27 13:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 1, 1, 19, 103, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (81, '2026-07-29 08:14:04', NULL, NULL, '2026-07-27 15:30:00', '2026-07-27 15:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'canceled', 1, 'in-clinic', 0, NULL, 1, 19, 104, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (82, '2026-07-29 08:14:04', NULL, NULL, '2026-07-28 10:30:00', '2026-07-28 10:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, 0, 1, 19, 105, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (83, '2026-07-29 08:14:04', NULL, NULL, '2026-07-28 12:00:00', '2026-07-28 12:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'pending', 0, 'in-clinic', 0, NULL, 1, 19, 101, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (84, '2026-07-29 08:14:04', NULL, NULL, '2026-07-28 13:30:00', '2026-07-28 13:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 1, 0, 19, 102, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (85, '2026-07-29 08:14:04', NULL, NULL, '2026-07-29 10:30:00', '2026-07-29 10:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, NULL, 1, 19, 103, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (86, '2026-07-29 08:14:04', NULL, NULL, '2026-07-29 11:30:00', '2026-07-29 11:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, NULL, 0, 19, 104, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (87, '2026-07-29 08:14:04', NULL, NULL, '2026-07-29 13:00:00', '2026-07-29 13:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 1, 1, 19, 105, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (88, '2026-07-29 08:14:04', NULL, NULL, '2026-07-29 15:30:00', '2026-07-29 15:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, NULL, 1, 19, 106, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (89, '2026-07-29 08:14:04', NULL, NULL, '2026-07-30 10:30:00', '2026-07-30 10:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, 0, 1, 19, 101, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (90, '2026-07-29 08:14:04', NULL, NULL, '2026-07-30 11:30:00', '2026-07-30 11:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'canceled', 1, 'in-clinic', 0, NULL, 1, 19, 102, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (91, '2026-07-29 08:14:04', NULL, NULL, '2026-07-30 13:00:00', '2026-07-30 13:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'pending', 0, 'in-clinic', 0, NULL, 1, 19, 103, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (92, '2026-07-29 08:14:04', NULL, NULL, '2026-07-31 10:30:00', '2026-07-31 10:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 1, 1, 19, 104, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (93, '2026-07-29 08:14:04', NULL, NULL, '2026-07-31 12:00:00', '2026-07-31 12:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, NULL, 1, 19, 105, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (94, '2026-07-29 08:14:04', NULL, NULL, '2026-07-31 15:30:00', '2026-07-31 15:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, NULL, 0, 19, 106, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (95, '2026-07-29 08:14:04', NULL, NULL, '2026-08-04 09:30:00', '2026-08-04 09:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, 0, 1, 19, 101, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (96, '2026-07-29 08:14:04', NULL, NULL, '2026-08-01 13:00:00', '2026-08-01 13:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, 0, 1, 19, 102, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (97, '2026-07-29 08:14:04', NULL, NULL, '2026-08-02 11:00:00', '2026-08-02 11:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'unavailable', 0, 'in-clinic', 1, NULL, 0, 19, NULL, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (98, '2026-07-29 08:15:36', NULL, NULL, '2026-07-27 10:45:00', '2026-07-27 11:00:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 1, 1, 19, 120, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (99, '2026-07-29 08:15:36', NULL, NULL, '2026-07-27 12:15:00', '2026-07-27 12:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'pending', 0, 'video', 0, NULL, 0, 19, 121, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (100, '2026-07-29 08:15:36', NULL, NULL, '2026-07-27 15:15:00', '2026-07-27 15:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 0, 1, 19, 122, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (101, '2026-07-29 08:15:36', NULL, NULL, '2026-07-28 11:15:00', '2026-07-28 11:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, NULL, 1, 19, 123, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (102, '2026-07-29 08:15:36', NULL, NULL, '2026-07-28 13:15:00', '2026-07-28 13:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'canceled', 1, 'in-clinic', 0, NULL, 1, 19, 124, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (103, '2026-07-29 08:15:36', NULL, NULL, '2026-07-29 10:45:00', '2026-07-29 11:00:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 0, 1, 19, 120, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (104, '2026-07-29 08:15:36', NULL, NULL, '2026-07-29 12:15:00', '2026-07-29 12:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, 1, 1, 19, 121, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (105, '2026-07-29 08:15:36', NULL, NULL, '2026-07-29 15:15:00', '2026-07-29 15:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'pending', 0, 'in-clinic', 0, NULL, 0, 19, 122, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (106, '2026-07-29 08:15:36', NULL, NULL, '2026-07-30 11:15:00', '2026-07-30 11:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 1, 1, 19, 123, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (107, '2026-07-29 08:15:36', NULL, NULL, '2026-07-30 13:45:00', '2026-07-30 14:00:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, NULL, 1, 19, 124, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (108, '2026-07-29 08:15:36', NULL, NULL, '2026-07-31 10:45:00', '2026-07-31 11:00:00', NULL, NULL, NULL, NULL, '#7cbae8', 'canceled', 1, 'in-clinic', 0, NULL, 0, 19, 120, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (109, '2026-07-29 08:15:36', NULL, NULL, '2026-07-31 12:30:00', '2026-07-31 12:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 0, 1, 19, 121, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (110, '2026-07-29 08:15:36', '2026-07-30 10:46:27', NULL, '2026-07-31 15:15:00', '2026-07-31 15:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'Canceled', 1, 'video', 0, 1, 1, 19, 122, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (134, '2026-07-29 08:21:51', '2026-08-01 16:07:29', NULL, '2026-08-01 09:15:00', '2026-08-01 09:30:00', '', '', '', NULL, '#7cbae8', 'Canceled', 1, 'in-clinic', 0, 1, 1, 19, 130, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (135, '2026-07-29 08:21:51', NULL, NULL, '2026-08-03 10:45:00', '2026-08-03 11:00:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, NULL, 1, 19, 131, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (136, '2026-07-29 08:21:51', NULL, NULL, '2026-08-03 11:15:00', '2026-08-03 11:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'pending', 0, 'in-clinic', 0, NULL, 0, 19, 132, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (137, '2026-07-29 08:21:51', NULL, NULL, '2026-08-03 11:45:00', '2026-08-03 12:00:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 0, 1, 19, 133, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (138, '2026-07-29 08:21:51', NULL, NULL, '2026-08-03 12:15:00', '2026-08-03 12:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'canceled', 1, 'in-clinic', 0, NULL, 1, 19, 134, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (139, '2026-07-29 08:21:51', NULL, NULL, '2026-08-03 13:00:00', '2026-08-03 13:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, 1, 1, 19, 135, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (140, '2026-07-29 08:21:51', NULL, NULL, '2026-08-03 13:30:00', '2026-08-03 13:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, NULL, 0, 19, 136, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (141, '2026-07-29 08:21:51', NULL, NULL, '2026-08-03 15:00:00', '2026-08-03 15:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, 0, 1, 19, 137, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (142, '2026-07-29 08:21:51', NULL, NULL, '2026-08-03 15:30:00', '2026-08-03 15:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'pending', 0, 'in-clinic', 0, NULL, 0, 19, 138, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (143, '2026-07-29 08:21:51', NULL, NULL, '2026-08-03 16:00:00', '2026-08-03 16:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 1, 1, 19, 139, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (144, '2026-07-29 08:21:51', '2026-08-03 11:52:25', NULL, '2026-08-03 09:00:00', '2026-08-03 09:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'Canceled', 1, 'in-clinic', 0, NULL, 1, 19, 130, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (145, '2026-07-29 08:21:51', '2026-08-01 15:52:59', NULL, '2026-08-04 10:45:00', '2026-08-04 11:00:00', '', '', '', NULL, '#7cbae8', 'Rescheduled', 0, 'in-clinic', 0, 1, 1, 19, 131, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (146, '2026-07-29 08:21:51', NULL, NULL, '2026-08-04 11:15:00', '2026-08-04 11:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'canceled', 1, 'in-clinic', 0, NULL, 0, 19, 132, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (147, '2026-07-29 08:21:51', NULL, NULL, '2026-08-04 11:45:00', '2026-08-04 12:00:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, 0, 1, 19, 133, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (148, '2026-07-29 08:21:51', NULL, NULL, '2026-08-04 12:15:00', '2026-08-04 12:30:00', NULL, NULL, NULL, NULL, '#7cbae8', 'pending', 0, 'in-clinic', 0, NULL, 0, 19, 134, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (149, '2026-07-29 08:21:51', NULL, NULL, '2026-08-04 13:00:00', '2026-08-04 13:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 1, 1, 19, 135, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (150, '2026-07-29 08:21:51', NULL, NULL, '2026-08-04 13:30:00', '2026-08-04 13:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'video', 0, NULL, 1, 19, 136, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (151, '2026-07-29 08:21:51', NULL, NULL, '2026-08-04 15:00:00', '2026-08-04 15:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 0, 1, 19, 137, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (152, '2026-07-29 08:21:51', NULL, NULL, '2026-08-04 15:30:00', '2026-08-04 15:45:00', NULL, NULL, NULL, NULL, '#7cbae8', 'canceled', 1, 'video', 0, NULL, 0, 19, 138, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (153, '2026-07-29 08:21:51', NULL, NULL, '2026-08-04 16:00:00', '2026-08-04 16:15:00', NULL, NULL, NULL, NULL, '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 1, 1, 19, 139, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (154, '2026-07-29 14:22:07', '2026-07-29 14:22:07', '2026-07-29 14:22:07', '2026-07-29 11:00:00', '2026-07-29 11:15:00', '', '', '', 'P6790YZEjQn4', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 143, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (155, '2026-07-30 10:52:00', '2026-07-30 10:53:21', '2026-07-30 10:52:00', '2026-08-03 11:15:00', '2026-08-03 11:30:00', '', '', '', 'jMskmyNeHA85', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 1, 19, 102, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (158, '2026-07-31 17:00:18', '2026-07-31 17:00:18', '2026-07-31 17:00:18', '2026-08-03 10:15:00', '2026-08-03 10:30:00', '', '', '', 'o6hiIBPGbLEn', '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 0, 1, 19, 144, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (159, '2026-07-31 17:02:35', '2026-08-01 14:57:28', '2026-07-31 17:02:35', '2026-08-01 09:00:00', '2026-08-01 09:15:00', '', '', '', 'd9lGZievFb1w', '#7cbae8', 'booked', 0, 'in-clinic', 0, 0, 1, 19, 144, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (160, '2026-07-31 17:47:01', '2026-07-31 17:47:01', '2026-07-31 17:47:01', '2026-07-31 09:30:00', '2026-07-31 09:45:00', '', '', '', 'JZEH6XNUvo2f', '#7cbae8', 'Booked', 0, 'video', 0, NULL, 0, 19, 145, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (162, '2026-08-01 13:58:45', '2026-08-01 14:03:53', '2026-08-01 13:58:45', '2026-08-04 09:00:00', '2026-08-04 09:15:00', '', '', '', 'jP2il1xtcakm', '#7cbae8', 'confirmed', 0, 'video', 0, 1, 0, 19, 146, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (163, '2026-08-01 15:56:39', '2026-08-01 17:12:21', '2026-08-01 15:56:39', '2026-08-01 09:30:00', '2026-08-01 09:45:00', '', '', '', 'Vz1iGUfLrSMv', '#7cbae8', 'Rescheduled', 0, 'in-clinic', 0, 0, 0, 19, 147, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (164, '2026-08-01 17:05:26', '2026-08-01 17:05:26', '2026-08-01 17:05:26', '2026-08-01 09:45:00', '2026-08-01 10:00:00', '', '', '', 'rbweV6TxA3dP', '#7cbae8', 'Booked', 0, 'video', 0, NULL, 0, 19, 148, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (166, '2026-08-03 13:57:16', '2026-08-03 13:57:16', '2026-08-03 13:57:16', '2026-08-03 09:30:00', '2026-08-03 09:45:00', '', '', '', 'OwJnWVa62hAT', '#7cbae8', 'Booked', 0, 'video', 0, NULL, 0, 19, 149, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (167, '2026-08-03 13:57:45', '2026-08-03 13:57:45', '2026-08-03 13:57:45', '2026-08-03 09:45:00', '2026-08-03 10:00:00', '', '', '', '5VoYS0cMyCOz', '#7cbae8', 'Booked', 0, 'video', 0, NULL, 0, 19, 150, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (168, '2026-08-05 13:07:39', '2026-08-05 13:07:39', '2026-08-05 13:07:39', '2026-08-05 15:45:00', '2026-08-05 16:00:00', NULL, NULL, 'erfvgerfverf', 'AWnmH3l8RPkj', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 143, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (169, '2026-08-05 13:13:01', '2026-08-05 13:13:01', '2026-08-05 13:13:01', '2026-08-05 16:00:00', '2026-08-05 16:15:00', NULL, NULL, 'hellohgejhfvbjdce evfjebv', 'rPcLlkON5oBz', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 151, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (170, '2026-08-05 14:17:46', '2026-08-05 14:17:46', '2026-08-05 14:17:46', '2026-08-05 12:45:00', '2026-08-05 13:00:00', NULL, NULL, 'efcecf', 'sIyroxUL5HW2', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 152, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (171, '2026-08-06 11:28:42', '2026-08-06 11:28:42', '2026-08-06 11:28:42', '2026-08-06 10:15:00', '2026-08-06 10:30:00', NULL, NULL, 'wefdwefew', 'cUajWBLhHyx2', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 153, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (172, '2026-08-06 12:09:09', '2026-08-06 12:09:09', '2026-08-06 12:09:09', '2026-08-06 12:45:00', '2026-08-06 13:00:00', NULL, NULL, 'wedcweecdewcddc', 'PYvublohsKMU', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 143, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (173, '2026-08-06 13:06:48', '2026-08-06 13:06:48', '2026-08-06 13:06:48', '2026-08-06 13:15:00', '2026-08-06 13:30:00', NULL, NULL, 'wqdwqqedwedwd', 'BwumdjXFifZV', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 154, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (174, '2026-08-06 13:39:50', '2026-08-06 13:39:50', '2026-08-06 13:39:50', '2026-08-06 13:45:00', '2026-08-06 14:00:00', NULL, NULL, 'dwedweddwq', '2K4wpASmdtl7', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 155, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (175, '2026-08-06 13:42:01', '2026-08-06 13:42:01', '2026-08-06 13:42:01', '2026-08-07 09:30:00', '2026-08-07 09:45:00', NULL, NULL, 'cwew', '3nAfsG4pCJFN', '#7cbae8', 'confirmed', 0, 'in-clinic', 0, NULL, 0, 19, 156, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (176, '2026-08-06 14:30:16', '2026-08-06 14:30:16', '2026-08-06 14:30:16', '2026-08-08 10:30:00', '2026-08-08 10:45:00', NULL, NULL, 'sdcsdcsdc', 'aBVrF6kYP1X5', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 157, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (177, '2026-08-06 14:45:18', '2026-08-06 14:45:18', '2026-08-06 14:45:18', '2026-08-10 10:30:00', '2026-08-10 10:45:00', NULL, NULL, 'ertfewrferfer', '5ep2qYnrucvi', '#7cbae8', 'Booked', 0, 'video', 0, 0, 0, 19, 158, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (178, '2026-08-06 14:48:09', '2026-08-06 14:48:09', '2026-08-06 14:48:09', '2026-08-10 11:45:00', '2026-08-10 12:00:00', NULL, NULL, 'sdwqdxwqxd', 'r3Ew5Z7J1Lgh', '#7cbae8', 'confirmed', 0, 'in-clinic', 0, 0, 1, 19, 159, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (179, '2026-08-06 14:50:10', '2026-08-06 14:50:10', '2026-08-06 14:50:10', '2026-08-07 16:15:00', '2026-08-07 16:30:00', NULL, NULL, 'ewfwedc', 'n1VCJouXkNbS', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 160, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (180, '2026-08-07 10:26:09', '2026-08-07 10:26:09', '2026-08-07 10:26:09', '2026-08-07 12:15:00', '2026-08-07 12:30:00', NULL, NULL, 'dcfwsewdwedwd', 'x6I1Nn387fhp', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 161, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (181, '2026-08-07 13:08:46', '2026-08-07 13:08:46', '2026-08-07 13:08:46', '2026-08-07 09:00:00', '2026-08-07 09:15:00', '', '', '', 'NA1F3d87rTol', '#7cbae8', 'Booked', 0, 'video', 0, NULL, 0, 19, 162, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (182, '2026-08-07 16:43:25', '2026-08-10 10:51:19', '2026-08-07 16:43:25', '2026-08-10 13:30:00', '2026-08-10 13:45:00', NULL, NULL, 'wsdwsdwedwqd', 'i3tUcvuZJVLm', '#7cbae8', 'Canceled', 1, 'in-clinic', 0, NULL, 0, 19, 163, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (183, '2026-08-10 10:56:14', '2026-08-10 10:56:14', '2026-08-10 10:56:14', '2026-08-10 09:00:00', '2026-08-10 09:15:00', '', '', '', '8Z2TsOkXj4YI', '#7cbae8', 'Booked', 0, 'in-clinic', 0, 0, 0, 19, 164, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (184, '2026-08-13 11:05:40', '2026-08-13 11:05:40', '2026-08-13 11:05:40', '2026-08-17 10:00:00', '2026-08-17 10:15:00', '', '', '', 'sU94N0SuwrlJ', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 163, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (185, '2026-08-14 16:12:02', '2026-08-14 16:12:02', '2026-08-14 16:12:02', '2026-08-15 09:00:00', '2026-08-15 09:15:00', NULL, NULL, '[VIDEO CALL APPOINTMENT] fujhjh', '4PSO1Rqpclan', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 19, 170, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (186, '2026-08-14 16:23:08', '2026-08-14 16:23:08', '2026-08-14 16:23:08', '2026-08-17 09:30:00', '2026-08-17 09:45:00', NULL, NULL, 'erfeffvrvc', 'kDqz7LVIaivG', '#7cbae8', 'Booked', 0, 'video', 0, NULL, 0, 19, 171, 5, NULL, NULL);
INSERT INTO `ea_appointments` (`id`, `create_datetime`, `update_datetime`, `book_datetime`, `start_datetime`, `end_datetime`, `location`, `meeting_link`, `notes`, `hash`, `color`, `status`, `is_canceled`, `appointment_type`, `is_unavailability`, `check_type`, `is_whatsapp_sent`, `id_users_provider`, `id_users_customer`, `id_services`, `id_google_calendar`, `id_caldav_calendar`) VALUES (187, '2026-08-14 17:59:57', '2026-08-14 17:59:57', '2026-08-14 17:59:57', '2026-08-15 10:45:00', '2026-08-15 11:00:00', '', '', '', '7mMlqUKr0J8d', '#7cbae8', 'Booked', 0, 'in-clinic', 0, NULL, 0, 167, 171, 5, NULL, NULL);


#
# TABLE STRUCTURE FOR: ea_blocked_periods
#

DROP TABLE IF EXISTS `ea_blocked_periods`;

CREATE TABLE `ea_blocked_periods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `start_datetime` datetime DEFAULT NULL,
  `end_datetime` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: ea_consents
#

DROP TABLE IF EXISTS `ea_consents`;

CREATE TABLE `ea_consents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_users` int(11) DEFAULT NULL,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL,
  `first_name` varchar(256) DEFAULT NULL,
  `last_name` varchar(256) DEFAULT NULL,
  `email` varchar(512) DEFAULT NULL,
  `ip` varchar(256) DEFAULT NULL,
  `type` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `consents_users` (`id_users`),
  CONSTRAINT `consents_users` FOREIGN KEY (`id_users`) REFERENCES `ea_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: ea_db_backups
#

DROP TABLE IF EXISTS `ea_db_backups`;

CREATE TABLE `ea_db_backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_data` longblob DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ea_db_backups` (`id`, `backup_name`, `backup_data`, `created_at`) VALUES (12, 'db-backup-2026-08-18_11-22-56.zip', NULL, '2026-08-18 11:22:56');


#
# TABLE STRUCTURE FOR: ea_ea_db_backups
#

DROP TABLE IF EXISTS `ea_ea_db_backups`;

CREATE TABLE `ea_ea_db_backups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_data` longblob NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: ea_migrations
#

DROP TABLE IF EXISTS `ea_migrations`;

CREATE TABLE `ea_migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ea_migrations` (`version`) VALUES ('69');


#
# TABLE STRUCTURE FOR: ea_roles
#

DROP TABLE IF EXISTS `ea_roles`;

CREATE TABLE `ea_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `slug` varchar(256) DEFAULT NULL,
  `is_admin` tinyint(4) DEFAULT NULL,
  `appointments` int(11) DEFAULT NULL,
  `customers` int(11) DEFAULT NULL,
  `services` int(11) DEFAULT NULL,
  `users` int(11) DEFAULT NULL,
  `system_settings` int(11) DEFAULT NULL,
  `user_settings` int(11) DEFAULT NULL,
  `webhooks` int(11) DEFAULT NULL,
  `blocked_periods` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ea_roles` (`id`, `create_datetime`, `update_datetime`, `name`, `slug`, `is_admin`, `appointments`, `customers`, `services`, `users`, `system_settings`, `user_settings`, `webhooks`, `blocked_periods`) VALUES (1, NULL, NULL, 'Administrator', 'admin', 1, 15, 15, 15, 15, 15, 15, 15, 15);
INSERT INTO `ea_roles` (`id`, `create_datetime`, `update_datetime`, `name`, `slug`, `is_admin`, `appointments`, `customers`, `services`, `users`, `system_settings`, `user_settings`, `webhooks`, `blocked_periods`) VALUES (2, NULL, NULL, 'Provider', 'provider', 0, 15, 15, 15, 15, 15, 15, 15, 15);
INSERT INTO `ea_roles` (`id`, `create_datetime`, `update_datetime`, `name`, `slug`, `is_admin`, `appointments`, `customers`, `services`, `users`, `system_settings`, `user_settings`, `webhooks`, `blocked_periods`) VALUES (3, NULL, NULL, 'Customer', 'customer', 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ea_roles` (`id`, `create_datetime`, `update_datetime`, `name`, `slug`, `is_admin`, `appointments`, `customers`, `services`, `users`, `system_settings`, `user_settings`, `webhooks`, `blocked_periods`) VALUES (4, NULL, NULL, 'Secretary', 'secretary', 0, 15, 15, 0, 0, 0, 15, 0, 0);


#
# TABLE STRUCTURE FOR: ea_secretaries_providers
#

DROP TABLE IF EXISTS `ea_secretaries_providers`;

CREATE TABLE `ea_secretaries_providers` (
  `id_users_secretary` int(11) NOT NULL,
  `id_users_provider` int(11) NOT NULL,
  PRIMARY KEY (`id_users_secretary`,`id_users_provider`),
  KEY `secretaries_users_provider` (`id_users_provider`),
  CONSTRAINT `secretaries_users_provider` FOREIGN KEY (`id_users_provider`) REFERENCES `ea_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `secretaries_users_secretary` FOREIGN KEY (`id_users_secretary`) REFERENCES `ea_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `ea_secretaries_providers` (`id_users_secretary`, `id_users_provider`) VALUES (165, 19);
INSERT INTO `ea_secretaries_providers` (`id_users_secretary`, `id_users_provider`) VALUES (166, 19);


#
# TABLE STRUCTURE FOR: ea_service_categories
#

DROP TABLE IF EXISTS `ea_service_categories`;

CREATE TABLE `ea_service_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ea_service_categories` (`id`, `create_datetime`, `update_datetime`, `name`, `description`) VALUES (1, '2026-07-23 14:53:51', '2026-07-23 14:53:51', 'Cardiology', 'wvhchjervcher');
INSERT INTO `ea_service_categories` (`id`, `create_datetime`, `update_datetime`, `name`, `description`) VALUES (2, '2026-07-23 14:58:46', '2026-07-23 14:58:46', 'Orthopedics', 'dwcwcwc');
INSERT INTO `ea_service_categories` (`id`, `create_datetime`, `update_datetime`, `name`, `description`) VALUES (3, '2026-07-23 14:59:01', '2026-07-23 14:59:01', 'Dermatology', 'wdcew');


#
# TABLE STRUCTURE FOR: ea_services
#

DROP TABLE IF EXISTS `ea_services`;

CREATE TABLE `ea_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `currency` varchar(32) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `slot_interval` int(11) DEFAULT 15,
  `color` varchar(256) DEFAULT '#7cbae8',
  `location` text DEFAULT NULL,
  `attendants_number` int(11) DEFAULT 1,
  `is_private` tinyint(4) DEFAULT 0,
  `id_service_categories` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_service_categories` (`id_service_categories`),
  CONSTRAINT `services_service_categories` FOREIGN KEY (`id_service_categories`) REFERENCES `ea_service_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ea_services` (`id`, `create_datetime`, `update_datetime`, `name`, `duration`, `price`, `currency`, `description`, `slot_interval`, `color`, `location`, `attendants_number`, `is_private`, `id_service_categories`) VALUES (5, '2026-07-24 13:06:57', '2026-07-24 13:07:34', 'Dr. Sahu Clinic', 15, '1700.00', NULL, NULL, 15, '#7cbae8', NULL, 1, 0, NULL);


#
# TABLE STRUCTURE FOR: ea_services_providers
#

DROP TABLE IF EXISTS `ea_services_providers`;

CREATE TABLE `ea_services_providers` (
  `id_users` int(11) NOT NULL,
  `id_services` int(11) NOT NULL,
  PRIMARY KEY (`id_users`,`id_services`),
  KEY `services_providers_services` (`id_services`),
  CONSTRAINT `services_providers_services` FOREIGN KEY (`id_services`) REFERENCES `ea_services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `services_providers_users_provider` FOREIGN KEY (`id_users`) REFERENCES `ea_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ea_services_providers` (`id_users`, `id_services`) VALUES (19, 5);
INSERT INTO `ea_services_providers` (`id_users`, `id_services`) VALUES (167, 5);


#
# TABLE STRUCTURE FOR: ea_settings
#

DROP TABLE IF EXISTS `ea_settings`;

CREATE TABLE `ea_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `name` varchar(512) DEFAULT NULL,
  `value` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (1, NULL, NULL, '2026-07-31 15:32:54', 'company_working_plan', '{\"sunday\":null,\"monday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"tuesday\":{\"start\":\"09:00\",\"end\":\"14:15\",\"breaks\":[]},\"wednesday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"thursday\":{\"start\":\"09:00\",\"end\":\"14:15\",\"breaks\":[]},\"friday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"saturday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]}}');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (2, NULL, NULL, '2026-07-31 15:32:54', 'book_advance_timeout', '30');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (3, NULL, NULL, NULL, 'google_analytics_code', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (4, NULL, NULL, '2026-08-13 16:56:26', 'customer_notifications', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (5, NULL, NULL, '2026-07-23 11:22:06', 'date_format', 'DMY');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (6, NULL, NULL, '2026-08-13 16:56:26', 'require_captcha', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (7, NULL, NULL, '2026-07-23 11:22:06', 'time_format', 'regular');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (8, NULL, NULL, NULL, 'display_cookie_notice', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (9, NULL, NULL, NULL, 'cookie_notice_content', 'Cookie notice content.');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (10, NULL, NULL, NULL, 'display_terms_and_conditions', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (11, NULL, NULL, NULL, 'terms_and_conditions_content', 'Terms and conditions content.');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (12, NULL, NULL, NULL, 'display_privacy_policy', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (13, NULL, NULL, NULL, 'privacy_policy_content', 'Privacy policy content.');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (14, NULL, NULL, '2026-07-23 11:22:06', 'first_weekday', 'sunday');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (16, NULL, NULL, NULL, 'api_token', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (17, NULL, NULL, '2026-08-13 16:56:26', 'display_any_provider', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (18, NULL, NULL, '2026-08-13 16:56:26', 'display_first_name', '1');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (19, NULL, NULL, '2026-08-13 16:56:26', 'require_first_name', '1');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (20, NULL, NULL, '2026-08-13 16:56:26', 'display_last_name', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (21, NULL, NULL, '2026-08-13 16:56:26', 'require_last_name', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (22, NULL, NULL, '2026-08-13 16:56:26', 'display_email', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (23, NULL, NULL, '2026-08-13 16:56:26', 'require_email', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (24, NULL, NULL, '2026-08-13 16:56:26', 'display_phone_number', '1');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (25, NULL, NULL, '2026-08-13 16:56:26', 'require_phone_number', '1');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (26, NULL, NULL, '2026-08-13 16:56:26', 'display_address', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (27, NULL, NULL, '2026-08-13 16:56:26', 'require_address', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (28, NULL, NULL, '2026-08-13 16:56:26', 'display_city', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (29, NULL, NULL, '2026-08-13 16:56:26', 'require_city', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (30, NULL, NULL, '2026-08-13 16:56:26', 'display_zip_code', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (31, NULL, NULL, '2026-08-13 16:56:26', 'require_zip_code', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (32, NULL, NULL, '2026-08-13 16:56:26', 'display_notes', '1');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (33, NULL, NULL, '2026-08-13 16:56:26', 'require_notes', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (34, NULL, NULL, NULL, 'matomo_analytics_url', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (35, NULL, NULL, '2026-08-13 16:56:26', 'display_delete_personal_information', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (36, NULL, NULL, '2026-08-13 16:56:26', 'disable_booking', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (37, NULL, NULL, '2026-08-13 16:56:27', 'disable_booking_message', '<p style=\"text-align:center;\">Thanks for stopping by!</p><p style=\"text-align:center;\">We are not accepting new appointments at the moment, please check back again later.</p>');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (38, NULL, NULL, '2026-07-23 11:22:06', 'company_logo', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (39, NULL, NULL, '2026-07-23 11:22:06', 'company_color', '#ffffff');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (40, NULL, NULL, '2026-08-13 16:56:26', 'display_login_button', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (41, NULL, NULL, '2026-07-23 11:22:06', 'theme', 'default');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (42, NULL, '2026-07-23 11:20:47', '2026-08-13 16:56:26', 'limit_customer_access', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (43, NULL, NULL, '2026-07-31 15:32:54', 'future_booking_limit', '90');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (44, NULL, NULL, '2026-07-31 15:32:54', 'appointment_status_options', '[\"Booked\",\"Confirmed\",\"Rescheduled\",\"Cancelled\",\"Draft\"]');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (45, NULL, NULL, '2026-08-13 16:56:26', 'display_custom_field_1', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (46, NULL, NULL, '2026-08-13 16:56:26', 'require_custom_field_1', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (47, NULL, NULL, '2026-08-13 16:56:26', 'label_custom_field_1', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (48, NULL, NULL, '2026-08-13 16:56:26', 'display_custom_field_2', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (49, NULL, NULL, '2026-08-13 16:56:26', 'require_custom_field_2', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (50, NULL, NULL, '2026-08-13 16:56:26', 'label_custom_field_2', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (51, NULL, NULL, '2026-08-13 16:56:26', 'display_custom_field_3', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (52, NULL, NULL, '2026-08-13 16:56:26', 'require_custom_field_3', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (53, NULL, NULL, '2026-08-13 16:56:26', 'label_custom_field_3', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (54, NULL, NULL, '2026-08-13 16:56:26', 'display_custom_field_4', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (55, NULL, NULL, '2026-08-13 16:56:26', 'require_custom_field_4', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (56, NULL, NULL, '2026-08-13 16:56:26', 'label_custom_field_4', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (57, NULL, NULL, '2026-08-13 16:56:26', 'display_custom_field_5', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (58, NULL, NULL, '2026-08-13 16:56:26', 'require_custom_field_5', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (59, NULL, NULL, '2026-08-13 16:56:26', 'label_custom_field_5', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (60, NULL, NULL, NULL, 'matomo_analytics_site_id', '1');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (61, NULL, NULL, '2026-07-23 11:22:06', 'default_language', 'english');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (62, NULL, NULL, '2026-07-23 11:22:06', 'default_timezone', 'Asia/Kolkata');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (63, NULL, '2026-07-23 11:20:47', '2026-07-23 11:20:47', 'ldap_is_active', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (64, NULL, '2026-07-23 11:20:47', '2026-07-23 11:20:47', 'ldap_host', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (65, NULL, '2026-07-23 11:20:47', '2026-07-23 11:20:47', 'ldap_port', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (66, NULL, '2026-07-23 11:20:47', '2026-07-23 11:20:47', 'ldap_user_dn', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (67, NULL, '2026-07-23 11:20:47', '2026-07-23 11:20:47', 'ldap_password', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (68, NULL, '2026-07-23 11:20:47', '2026-07-23 11:20:47', 'ldap_base_dn', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (69, NULL, '2026-07-23 11:20:47', '2026-07-23 11:20:47', 'ldap_filter', '(&(objectClass=*)(|(cn={{KEYWORD}})(sn={{KEYWORD}})(mail={{KEYWORD}})(givenName={{KEYWORD}})(uid={{KEYWORD}})))');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (70, NULL, '2026-07-23 11:20:47', '2026-07-23 11:20:47', 'ldap_field_mapping', '{\n    \"first_name\": \"givenname\",\n    \"last_name\": \"sn\",\n    \"email\": \"mail\",\n    \"phone_number\": \"telephonenumber\",\n    \"username\": \"cn\"\n}');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (71, NULL, NULL, NULL, 'google_sync_feature', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (72, NULL, NULL, NULL, 'google_client_id', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (73, NULL, NULL, NULL, 'google_client_secret', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (74, NULL, NULL, NULL, 'data_retention_days', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (75, NULL, NULL, NULL, 'altcha_enabled', '0');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (76, NULL, NULL, NULL, 'altcha_hmac_key', '');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (77, NULL, NULL, NULL, 'altcha_max_number', '100000');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (78, NULL, NULL, NULL, 'altcha_expires', '300');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (79, NULL, '2026-07-23 11:20:48', '2026-07-23 11:22:06', 'company_name', 'Dr. Shahu');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (80, NULL, '2026-07-23 11:20:48', '2026-07-23 11:22:06', 'company_email', 'pp@gmail.com');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (81, NULL, '2026-07-23 11:20:48', '2026-07-23 11:22:06', 'company_link', 'https://drsahus.com/');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (82, 1, '2026-08-13 11:46:07', '2026-08-13 14:46:10', 'book_advance_timeout', '30');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (83, 1, '2026-08-13 11:46:07', '2026-08-13 14:46:10', 'future_booking_limit', '90');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (84, 1, '2026-08-13 11:46:07', '2026-08-13 14:46:10', 'company_working_plan', '{\"sunday\":null,\"monday\":null,\"tuesday\":null,\"wednesday\":null,\"thursday\":{\"start\":\"09:00\",\"end\":\"14:15\",\"breaks\":[]},\"friday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"saturday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]}}');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (85, 1, '2026-08-13 11:46:07', '2026-08-13 14:46:10', 'appointment_status_options', '[\"Booked\",\"Confirmed\",\"Rescheduled\",\"Cancelled\",\"Draft\"]');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (86, 19, '2026-08-13 11:58:05', '2026-08-13 17:12:59', 'book_advance_timeout', '30');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (87, 19, '2026-08-13 11:58:05', '2026-08-13 17:12:59', 'future_booking_limit', '90');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (88, 19, '2026-08-13 11:58:05', '2026-08-13 17:12:59', 'company_working_plan', '{\"sunday\":null,\"monday\":null,\"tuesday\":null,\"wednesday\":{\"start\":\"09:00\",\"end\":\"18:00\",\"breaks\":[]},\"thursday\":{\"start\":\"09:00\",\"end\":\"18:00\",\"breaks\":[]},\"friday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"saturday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]}}');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (89, 19, '2026-08-13 11:58:05', '2026-08-13 17:12:59', 'appointment_status_options', '[\"Booked\",\"Confirmed\",\"Rescheduled\",\"Cancelled\",\"Draft\"]');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (90, 165, '2026-08-13 12:24:57', '2026-08-13 12:25:54', 'book_advance_timeout', '30');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (91, 165, '2026-08-13 12:24:57', '2026-08-13 12:25:54', 'future_booking_limit', '90');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (92, 165, '2026-08-13 12:24:57', '2026-08-13 12:25:54', 'company_working_plan', '{\"sunday\":null,\"monday\":{\"start\":\"09:00\",\"end\":\"14:00\",\"breaks\":[]},\"tuesday\":{\"start\":\"09:00\",\"end\":\"13:00\",\"breaks\":[]},\"wednesday\":{\"start\":\"09:00\",\"end\":\"12:30\",\"breaks\":[]},\"thursday\":{\"start\":\"09:00\",\"end\":\"18:00\",\"breaks\":[]},\"friday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"saturday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]}}');
INSERT INTO `ea_settings` (`id`, `id_user`, `create_datetime`, `update_datetime`, `name`, `value`) VALUES (93, 165, '2026-08-13 12:24:57', '2026-08-13 12:25:54', 'appointment_status_options', '[\"Booked\",\"Confirmed\",\"Rescheduled\",\"Cancelled\",\"Draft\"]');


#
# TABLE STRUCTURE FOR: ea_user_settings
#

DROP TABLE IF EXISTS `ea_user_settings`;

CREATE TABLE `ea_user_settings` (
  `id_users` int(11) NOT NULL,
  `username` varchar(256) DEFAULT NULL,
  `password` varchar(512) DEFAULT NULL,
  `password_reset_token` varchar(64) DEFAULT NULL,
  `password_reset_expires` datetime DEFAULT NULL,
  `salt` varchar(512) DEFAULT NULL,
  `working_plan` text DEFAULT NULL,
  `working_plan_exceptions` text DEFAULT NULL,
  `notifications` tinyint(4) DEFAULT NULL,
  `google_sync` tinyint(4) DEFAULT NULL,
  `google_token` text DEFAULT NULL,
  `google_calendar` varchar(128) DEFAULT NULL,
  `caldav_sync` tinyint(4) DEFAULT 0,
  `caldav_url` varchar(512) DEFAULT NULL,
  `caldav_username` varchar(256) DEFAULT NULL,
  `caldav_password` varchar(256) DEFAULT NULL,
  `sync_past_days` int(11) DEFAULT 30,
  `sync_future_days` int(11) DEFAULT 90,
  `calendar_view` varchar(32) DEFAULT 'default',
  PRIMARY KEY (`id_users`),
  CONSTRAINT `user_settings_users` FOREIGN KEY (`id_users`) REFERENCES `ea_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ea_user_settings` (`id_users`, `username`, `password`, `password_reset_token`, `password_reset_expires`, `salt`, `working_plan`, `working_plan_exceptions`, `notifications`, `google_sync`, `google_token`, `google_calendar`, `caldav_sync`, `caldav_url`, `caldav_username`, `caldav_password`, `sync_past_days`, `sync_future_days`, `calendar_view`) VALUES (1, 'administrator', '$2y$12$dQgdfi.ruyrbdVdeYOYdG.GlDELjlTU.Ey6A30pe60lVAdap1iAAO', NULL, NULL, '15eae706262443c3d73fd393f604d4050547ae1c5bf405dc4521f7a19d276fb1', NULL, NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, 30, 90, 'default');
INSERT INTO `ea_user_settings` (`id_users`, `username`, `password`, `password_reset_token`, `password_reset_expires`, `salt`, `working_plan`, `working_plan_exceptions`, `notifications`, `google_sync`, `google_token`, `google_calendar`, `caldav_sync`, `caldav_url`, `caldav_username`, `caldav_password`, `sync_past_days`, `sync_future_days`, `calendar_view`) VALUES (19, 'Msahu', '$2y$12$u2wRbk5bxqx/qrjnSwhei.JHSpo6yLryTraBuI5d7YOhNxiwVy2ba', NULL, NULL, '99c0125f08f2bcb6823f79d1dc6682b0d5c623877bb94aa8732ede74c2c3b4c1', '{\"sunday\":null,\"monday\":{\"start\":\"09:00\",\"end\":\"18:00\",\"breaks\":[]},\"tuesday\":{\"start\":\"09:00\",\"end\":\"18:00\",\"breaks\":[]},\"wednesday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"thursday\":{\"start\":\"09:00\",\"end\":\"14:15\",\"breaks\":[]},\"friday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"saturday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]}}', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, 30, 90, 'default');
INSERT INTO `ea_user_settings` (`id_users`, `username`, `password`, `password_reset_token`, `password_reset_expires`, `salt`, `working_plan`, `working_plan_exceptions`, `notifications`, `google_sync`, `google_token`, `google_calendar`, `caldav_sync`, `caldav_url`, `caldav_username`, `caldav_password`, `sync_past_days`, `sync_future_days`, `calendar_view`) VALUES (165, 'staff', '$2y$12$myFG11NdXErOjY63Qity6OmFRpwbfDCfB/2.8Pa/3VYLFfz2OpzLW', NULL, NULL, '3fff77174b03d9f4fe89faad684c56d8b060b472433ef6e94e7274f9e0ca9b80', NULL, NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, 30, 90, 'default');
INSERT INTO `ea_user_settings` (`id_users`, `username`, `password`, `password_reset_token`, `password_reset_expires`, `salt`, `working_plan`, `working_plan_exceptions`, `notifications`, `google_sync`, `google_token`, `google_calendar`, `caldav_sync`, `caldav_url`, `caldav_username`, `caldav_password`, `sync_past_days`, `sync_future_days`, `calendar_view`) VALUES (166, 'STAFF1 ', '$2y$12$Ibvs5ydv.njXGeOmjIi3YOH8mbT/8QlksGRvuaCvIWDsrfkA8G20e', NULL, NULL, '9eef11c396d17ce76e6ba3ccb46caa24c8a65f638a635b595c96be8a8fed3c7d', NULL, NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, 30, 90, 'default');
INSERT INTO `ea_user_settings` (`id_users`, `username`, `password`, `password_reset_token`, `password_reset_expires`, `salt`, `working_plan`, `working_plan_exceptions`, `notifications`, `google_sync`, `google_token`, `google_calendar`, `caldav_sync`, `caldav_url`, `caldav_username`, `caldav_password`, `sync_past_days`, `sync_future_days`, `calendar_view`) VALUES (167, 'anshulraj', '$2y$12$L37j8ye8WsMxVQnKoAzdzusQYc4xYRnRjTbDHDpI68e61lWfgyIYC', NULL, NULL, '316651fdc0cd45466da006f9dc5346a63f202fa4cf8b25606e84631f7e527a44', '{\"sunday\":null,\"monday\":null,\"tuesday\":{\"start\":\"09:00\",\"end\":\"14:15\",\"breaks\":[]},\"wednesday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"thursday\":{\"start\":\"09:00\",\"end\":\"14:15\",\"breaks\":[]},\"friday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]},\"saturday\":{\"start\":\"09:00\",\"end\":\"16:30\",\"breaks\":[{\"start\":\"14:30\",\"end\":\"15:00\"}]}}', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, 30, 90, 'default');


#
# TABLE STRUCTURE FOR: ea_users
#

DROP TABLE IF EXISTS `ea_users`;

CREATE TABLE `ea_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `first_name` varchar(256) DEFAULT NULL,
  `last_name` varchar(512) DEFAULT NULL,
  `email` varchar(512) DEFAULT NULL,
  `mobile_number` varchar(128) DEFAULT NULL,
  `phone_number` varchar(128) DEFAULT NULL,
  `address` varchar(256) DEFAULT NULL,
  `city` varchar(256) DEFAULT NULL,
  `state` varchar(128) DEFAULT NULL,
  `zip_code` varchar(64) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `timezone` varchar(256) DEFAULT 'UTC',
  `language` varchar(256) DEFAULT 'english',
  `custom_field_1` text DEFAULT NULL,
  `custom_field_2` text DEFAULT NULL,
  `custom_field_3` text DEFAULT NULL,
  `custom_field_4` text DEFAULT NULL,
  `custom_field_5` text DEFAULT NULL,
  `is_private` tinyint(4) DEFAULT 0,
  `ldap_dn` text DEFAULT NULL,
  `id_roles` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_roles` (`id_roles`),
  CONSTRAINT `users_roles` FOREIGN KEY (`id_roles`) REFERENCES `ea_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (1, '2026-07-23 11:20:48', '2026-07-23 11:20:48', 'Dr Sahu', 'sahu', 'raj973anshul@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Europe/Berlin', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (19, '2026-07-24 14:30:54', '2026-08-13 11:26:41', 'Dr. Monashish ', 'sahu', 'raj973anshul@gmail.com', NULL, '', '', '', '', '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 2, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (101, '2026-07-29 08:14:04', NULL, 'Ramesh', 'Kumar', 'ramesh@example.com', NULL, '9876543210', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (102, '2026-07-29 08:14:04', '2026-07-30 10:53:21', 'Suresh', 'Singh', 'suresh@example.com', NULL, '9876543211', '', '', NULL, '', '', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (103, '2026-07-29 08:14:04', NULL, 'Amit', 'Sharma', 'amit@example.com', NULL, '9876543212', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (104, '2026-07-29 08:14:04', NULL, 'Priya', 'Verma', 'priya@example.com', NULL, '9876543213', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (105, '2026-07-29 08:14:04', NULL, 'Neha', 'Gupta', 'neha@example.com', NULL, '9876543214', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (106, '2026-07-29 08:14:04', NULL, 'Rahul', 'Verma', 'rahul@example.com', NULL, '9876543215', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (120, '2026-07-29 08:15:36', NULL, 'Rohan', 'Saxena', 'rohan@example.com', NULL, '9911223344', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (121, '2026-07-29 08:15:36', NULL, 'Pooja', 'Nair', 'pooja@example.com', NULL, '9922334455', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (122, '2026-07-29 08:15:36', NULL, 'Karan', 'Joshi', 'karan@example.com', NULL, '9933445566', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (123, '2026-07-29 08:15:36', NULL, 'Simran', 'Kaur', 'simran@example.com', NULL, '9944556677', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (124, '2026-07-29 08:15:36', NULL, 'Mohit', 'Agarwal', 'mohit@example.com', NULL, '9955667788', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (130, '2026-07-29 08:21:51', '2026-08-01 16:05:18', 'AlokSSS', 'MishraSSS', 'alok@example.com', NULL, '9899001122', '', '', NULL, '', '', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (131, '2026-07-29 08:21:51', '2026-08-01 15:52:59', 'Divya', 'Sen', 'divya@example.com', NULL, '9899002233', '', '', NULL, '', '', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (132, '2026-07-29 08:21:51', NULL, 'Manish', 'Gupta', 'manish@example.com', NULL, '9899003344', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (133, '2026-07-29 08:21:51', NULL, 'Poonam', 'Yadav', 'poonam@example.com', NULL, '9899004455', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (134, '2026-07-29 08:21:51', NULL, 'Sandeep', 'Reddy', 'sandeep@example.com', NULL, '9899005566', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (135, '2026-07-29 08:21:51', NULL, 'Meenakshi', 'Iyer', 'meenakshi@example.com', NULL, '9899006677', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (136, '2026-07-29 08:21:51', NULL, 'Vikas', 'Jain', 'vikas@example.com', NULL, '9899007788', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (137, '2026-07-29 08:21:51', NULL, 'Kriti', 'Sanon', 'kriti@example.com', NULL, '9899008899', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (138, '2026-07-29 08:21:51', NULL, 'Nikhil', 'Bansal', 'nikhil@example.com', NULL, '9899009900', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (139, '2026-07-29 08:21:51', NULL, 'Shreya', 'Ghoshal', 'shreya@example.com', NULL, '9899011122', NULL, NULL, NULL, NULL, NULL, 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (143, '2026-07-29 14:22:07', '2026-08-06 12:09:09', 'Anshul raj', 'manis kumar', NULL, NULL, '9319163194', '', '', NULL, '', 'wedcweecdewcddc', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (144, '2026-07-31 16:57:58', '2026-08-01 14:57:28', 'Sushila', 'manisha', '', NULL, '9718438375', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (145, '2026-07-31 17:47:01', '2026-07-31 17:47:01', 'rfcvrefvgrevrf3', NULL, '', NULL, '1236585888887', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (146, '2026-08-01 13:58:45', '2026-08-01 14:03:53', 'fgerfejfvjevfjefr', 'raj', '', NULL, '645646464646', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (147, '2026-08-01 15:56:39', '2026-08-01 17:12:21', 'ugcedvcjehvchjdcv', 'fvwshjcvchd', '', NULL, '64648749874', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (148, '2026-08-01 17:05:26', '2026-08-01 17:05:26', 'anshul', 'anshul', '', NULL, '6546465465465', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (149, '2026-08-03 13:57:16', '2026-08-03 13:57:16', 'dwedewdewqd', 'dwedewdewqd', '', NULL, '9319163194', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (150, '2026-08-03 13:57:45', '2026-08-03 13:57:45', 'asxsasd', 'asxsasd', '', NULL, '9319163194', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (151, '2026-08-05 13:13:01', '2026-08-05 13:13:01', 'rahul kumar', 'anshul raj', 'demo1@gmail.com', NULL, '9319163194', NULL, NULL, NULL, NULL, 'hellohgejhfvbjdce evfjebv', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (152, '2026-08-05 14:17:46', '2026-08-05 14:17:46', 'pp kumar', 'rr kumar', NULL, NULL, '1234567899', NULL, NULL, NULL, NULL, 'efcecf', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (153, '2026-08-06 11:28:42', '2026-08-06 11:28:42', 'pp kumar', 'rahul kumar', NULL, NULL, '1234567899', NULL, NULL, NULL, NULL, 'wefdwefew', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (154, '2026-08-06 13:06:48', '2026-08-06 13:06:48', 'asxsasd', 'asxsasd', NULL, NULL, '9319163194', NULL, NULL, NULL, NULL, 'wqdwqqedwedwd', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (155, '2026-08-06 13:39:50', '2026-08-06 13:39:50', 'pp kumar', 'rr kumar', NULL, NULL, '9319163194', NULL, NULL, NULL, NULL, 'dwedweddwq', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (156, '2026-08-06 13:42:01', '2026-08-06 13:42:01', 'manshi kumari', 'kumari neha', NULL, NULL, '1234567899', NULL, NULL, NULL, NULL, 'cwew', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (157, '2026-08-06 14:30:16', '2026-08-06 14:30:16', 'pp kumar', 'kk sharma', NULL, NULL, '1234567899', NULL, NULL, NULL, NULL, 'sdcsdcsdc', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (158, '2026-08-06 14:45:18', '2026-08-06 14:45:18', 'pp kumar', '', NULL, NULL, '1234567899', NULL, NULL, NULL, NULL, 'ertfewrferfer', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (159, '2026-08-06 14:48:09', '2026-08-06 14:48:09', 'Karan', 'Joshi', NULL, NULL, '9933445566', NULL, NULL, NULL, NULL, 'sdwqdxwqxd', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (160, '2026-08-06 14:50:10', '2026-08-06 14:50:10', 'rahul kumar', 'rahul kumar', NULL, NULL, '9319163194', NULL, NULL, NULL, NULL, 'ewfwedc', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (161, '2026-08-07 10:26:09', '2026-08-13 15:42:28', 'rahul kumar', 'kk sharma', '', NULL, '123456789943', '', '', NULL, '', 'dcfwsewdwedwd', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (162, '2026-08-07 13:08:46', '2026-08-07 13:08:46', 'wedcweadcwec', 'wdcec', '', NULL, '9319163194', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (163, '2026-08-07 16:43:25', '2026-08-13 11:05:40', 'qwdwqdwqed', 'qwdwqdwqed', '', NULL, '123456789999', '', '', NULL, '', 'wsdwsdwedwqd', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (164, '2026-08-10 10:56:14', '2026-08-10 10:56:14', 'sdacedcercwr', 'sdacedcercwr', '', NULL, '1236585888887', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (165, '2026-08-13 09:59:50', '2026-08-13 09:59:50', 'Drsahu', 'secretaries', 'drsahu@gmail.com', NULL, '9999573571', '', '', '', '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 4, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (166, '2026-08-13 12:53:30', '2026-08-13 12:53:30', 'STAFF1 ', 'STAFF1 ', 'staff1@gmail.com', NULL, '123456789', '', '', '', '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 4, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (167, '2026-08-13 15:39:45', '2026-08-13 15:39:45', 'anshul', 'raj', 'ar@gmail.com', NULL, '', '', '', '', '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 2, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (168, '2026-08-13 16:56:34', '2026-08-13 16:56:34', 'sdx', '', '', NULL, '9899001122', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (169, '2026-08-13 17:01:50', '2026-08-13 17:01:50', 'scsdaxcsdaxc', '', '', NULL, '9899002233', '', '', NULL, '', '', 'Asia/Kolkata', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, 19);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (170, '2026-08-14 16:12:02', '2026-08-14 16:12:02', 'pp kumar', 'pp kumar', NULL, NULL, '9319163194', NULL, NULL, NULL, NULL, '[VIDEO CALL APPOINTMENT] fujhjh', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);
INSERT INTO `ea_users` (`id`, `create_datetime`, `update_datetime`, `first_name`, `last_name`, `email`, `mobile_number`, `phone_number`, `address`, `city`, `state`, `zip_code`, `notes`, `timezone`, `language`, `custom_field_1`, `custom_field_2`, `custom_field_3`, `custom_field_4`, `custom_field_5`, `is_private`, `ldap_dn`, `id_roles`, `created_by`) VALUES (171, '2026-08-14 16:23:08', '2026-08-14 17:59:57', 'pp kumar', 'pp kumar', '', NULL, '9319163194', '', '', NULL, '', 'erfeffvrvc', 'UTC', 'english', NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL);


#
# TABLE STRUCTURE FOR: ea_webhooks
#

DROP TABLE IF EXISTS `ea_webhooks`;

CREATE TABLE `ea_webhooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `actions` text DEFAULT NULL,
  `secret_header` varchar(256) DEFAULT 'X-Ea-Token',
  `secret_token` varchar(512) DEFAULT NULL,
  `is_ssl_verified` tinyint(4) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: ea_working_plan_exceptions
#

DROP TABLE IF EXISTS `ea_working_plan_exceptions`;

CREATE TABLE `ea_working_plan_exceptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `breaks` text DEFAULT NULL,
  `id_users_provider` int(11) NOT NULL,
  `create_datetime` datetime DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `start_date` (`start_date`),
  KEY `end_date` (`end_date`),
  KEY `id_users_provider` (`id_users_provider`),
  CONSTRAINT `working_plan_exceptions_users_provider` FOREIGN KEY (`id_users_provider`) REFERENCES `ea_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

